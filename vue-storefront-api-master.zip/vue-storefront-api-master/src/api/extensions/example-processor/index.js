import { Router } from 'express'

module.exports = () => {
  let exampleApi = Router()

  return exampleApi
}
