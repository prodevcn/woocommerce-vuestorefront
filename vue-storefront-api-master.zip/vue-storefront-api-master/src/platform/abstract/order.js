class AbstractOrderProxy {
  create (orderData) {
  }
}

module.exports = AbstractOrderProxy
