class AbstractNewsletterProxy {
  subscribe (emailAddress) {
  }

  unsubscribe (customerToken) {
  }
}

module.exports = AbstractNewsletterProxy
